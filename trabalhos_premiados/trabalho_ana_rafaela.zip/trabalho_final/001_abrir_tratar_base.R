library(readr)
library(lubridate)
library(stringr)
library(dplyr)

#Importando os dados 
dados_covid_sp <-
  read.csv2(
    "https://raw.githubusercontent.com/seade-R/dados-covid-sp/master/data/dados_covid_sp.csv",
    encoding = "UTF-8"
  )

#Importando o dicionario das variaveis.
#Rodar se tiver duvidas em relação as variaveis
dicionario<-read_csv2("dicionario_variaveis.csv")


#Tratando os campos importantes
dados_covid_sp<-dados_covid_sp%>%filter(nome_munic !="Ignorado")
dados_covid_sp$ano_epidem <- epiyear(dados_covid_sp$datahora)
dados_covid_sp$semana_epidem_ajustada <- str_c(
  dados_covid_sp$ano_epidem,
  ifelse(epiweek(dados_covid_sp$datahora) < 10, "0", ""),
  epiweek(dados_covid_sp$datahora)
)

dados_covid_sp$anomes <- str_c(
  year(dados_covid_sp$datahora),
  ifelse(dados_covid_sp$mes < 10, "0", ""),
  dados_covid_sp$mes
)

dados_covid_sp$cidade_filtro <-
  str_to_upper(dados_covid_sp$nome_munic)


#Salvando o arquivo tratado no formato ".rds"
write_rds(dados_covid_sp, "dados_covid_sp.rds")
