library(readr)
library(dplyr)
library(stringr)
library(ggplot2)
library(gridExtra)

dados_covid_sp <- read_rds("dados_covid_sp.rds")

#FUNÇÃO QUE TRAZ OS DADOS SOBRE A COVID-19 PARA O ESTADO DE SÃO PAULO


resumo_estado <- function() {
  numero_casos <- dados_covid_sp %>% select(datahora, casos) %>%
    mutate(datahora = as.Date(datahora, "%Y-%m-%d")) %>%
    filter(datahora == max(datahora)) %>%
    summarise(total_casos = sum(casos))
  
  numero_obitos <- dados_covid_sp %>% select(datahora, obitos) %>%
    mutate(datahora = as.Date(datahora, "%Y-%m-%d")) %>%
    filter(datahora == max(datahora)) %>%
    summarise(total_obitos = sum(obitos))
  
  
  data_base <- max(dados_covid_sp$datahora)
  
  print(paste0("Estado de São Paulo - Dados atualizados até ", data_base))
  
  print(paste0(
    "São ",
    format(
      numero_casos$total_casos,
      decimal.mark = ",",
      big.mark = ".",
      big.interval = 3L
    ),
    " casos confirmados"
  ))
  
  print(paste0(
    "São ",
    format(
      numero_obitos$total_obitos,
      decimal.mark = ",",
      big.mark = ".",
      big.interval = 3L
    ),
    " óbitos por COVID-19"
  ))
  
  
  
  grafico_casos <- dados_covid_sp %>% group_by(anomes) %>%
    filter(datahora == max(datahora)) %>%
    summarise(casos = sum(casos)) %>%
    ggplot(aes(x = anomes, y = casos)) +
    geom_col(aes(x = anomes, y = casos), fill = "azure2") + ggtitle("Evolução do número de casos") +
    xlab("Período") + ylab("Número de casos") + theme_classic() +
    geom_text(aes(
      label = format(
        casos,
        decimal.mark = ",",
        big.mark = ".",
        big.interval = 3L
      )
    ),
    vjust = 1)
  
  grafico_obitos <- dados_covid_sp %>% group_by(anomes) %>%
    filter(datahora == max(datahora)) %>%
    summarise(obitos = sum(obitos)) %>%
    ggplot(aes(x = anomes, y = obitos)) +
    geom_col(aes(x = anomes, y = obitos), fill = "azure3") + ggtitle("Evolução do número de óbitos") +
    xlab("Período") + ylab("Número de óbitos") + theme_classic() +
    geom_text(aes(
      label = format(
        obitos,
        decimal.mark = ",",
        big.mark = ".",
        big.interval = 3L
      )
    ),
    vjust = 1)
  
  
  grid.arrange(grafico_casos, grafico_obitos)
  
  
}



#FUNÇÃO PARA FILTRAR OS DADOS SOBRE A COVID-19 DE UMA CIDADE EM ESPECIFICO

resumo_cidade <- function(cidade) {
  cidade <- str_to_upper(cidade)
  
  if (!cidade %in% dados_covid_sp$cidade_filtro) {
    print(paste0(
      "Cidade não localizada. Veja a lista de cidades, ela poderá te ajudar."
    ))
    lista_cidades <-
      dados_covid_sp %>% select(nome_munic) %>% distinct()
    View(lista_cidades)
    
  }
  else{
    casos_covid_filtrada <-
      dados_covid_sp %>%
      filter(cidade_filtro == cidade)
    
    qtde_casos_cidade <-
      casos_covid_filtrada %>%
      select(nome_munic, datahora, casos) %>%
      filter(datahora == max(datahora))
    
    qtde_obitos_cidade <-
      casos_covid_filtrada %>%
      select(nome_munic, datahora, obitos) %>%
      filter(datahora == max(datahora))
    
    taxa_letalidade <-
      casos_covid_filtrada %>%
      select(nome_munic, datahora, letalidade) %>%
      filter(datahora == max(datahora))
    
    obitos_por_100_mil <-
      casos_covid_filtrada %>%
      select(nome_munic, datahora, obitos_pc) %>%
      filter(datahora == max(datahora))
    
    casos_por_100_mil <-
      casos_covid_filtrada %>%
      select(nome_munic, datahora, casos_pc) %>%
      filter(datahora == max(datahora))
    
    
    data_base <- max(casos_covid_filtrada$datahora)
    localidade <-
      casos_covid_filtrada %>% select(nome_munic) %>% slice(1)
    
    print(paste0(
      "Dados atualizados até ",
      data_base,
      " para a cidade de ",
      localidade
    ))
    
    print(paste0(
      "São ",
      format(
        qtde_casos_cidade$casos,
        decimal.mark = ",",
        big.mark = ".",
        big.interval = 3L
      ),
      " casos confirmados"
    ))
    print(paste0(
      "Já são ",
      format(
        qtde_obitos_cidade$obitos,
        decimal.mark = ",",
        big.mark = ".",
        big.interval = 3L
      ),
      " óbitos por COVID-19"
    ))
    
    print(paste0("A taxa de letalidade é de ",
                 format(
                   round(taxa_letalidade$letalidade, 2), decimal.mark = ","
                 )))
    
    print(paste0(
      "São ",
      format(round(casos_por_100_mil$casos_pc, 0), decimal.mark = ","),
      " casos a cada 100 mil habitantes"
    ))
    
    print(paste0(
      "São ",
      format(round(obitos_por_100_mil$obitos_pc, 0), decimal.mark = ","),
      " mortes a cada 100 mil habitantes"
    ))
    
    
    grafico_casos <- casos_covid_filtrada %>% group_by(anomes) %>%
      summarise(casos = max(casos)) %>%
      ggplot(aes(x = anomes, y = casos)) +
      geom_col(fill = "azure3") + ggtitle("Evolução do número de casos") +
      xlab("Período") + ylab("Número de casos") + theme_classic() +
      geom_text(aes(
        label = format(
          casos,
          decimal.mark = ",",
          big.mark = ".",
          big.interval = 3L
        )
      ),
      vjust = 1)
    
    grafico_obitos <- casos_covid_filtrada %>% group_by(anomes) %>%
      summarise(obitos = max(obitos)) %>%
      ggplot(aes(x = anomes, y = obitos)) +
      geom_col(fill = "azure3") + ggtitle("Evolução do número de óbitos") +
      xlab("Período") + ylab("Número de óbitos") + theme_classic() +
      geom_text(aes(
        label = format(
          obitos,
          decimal.mark = ",",
          big.mark = ".",
          big.interval = 3L
        )
      ),
      vjust = 1)
    
    grid.arrange(grafico_casos, grafico_obitos)
    
  }
}

#FUNÇÃO TRAZ A LISTA DAS CIDADES COM OS MENORES E MAIORES NÚMEROS DE CASOS CONFIRMADOS POR 100 MIL HABITANTES
raking_cidades_casos <- function(quantidade = 5) {
  cidade_menores_casos <-
    dados_covid_sp %>% filter(datahora == max(datahora)) %>%
    select(nome_munic, casos_pc) %>%
    arrange(casos_pc) %>%
    slice(c(1:quantidade)) %>%
    ggplot(aes(x = reorder(nome_munic, casos_pc), y = casos_pc)) + geom_col(fill = "azure3") + ggtitle("Cidades com os menores números de casos por 100 mil habitantes") +
    xlab("Cidade") + ylab("Número de casos por 100 mil habitantes") + theme_classic() +
    geom_text(aes(
      label = format(
        round(casos_pc, 0),
        decimal.mark = ",",
        big.mark = ".",
        big.interval = 3L
      )
    ),
    vjust = 1)
  
  cidade_maiores_casos <-
    dados_covid_sp %>% filter(datahora == max(datahora)) %>%
    select(nome_munic, casos_pc) %>%
    arrange(desc(casos_pc)) %>%
    slice(c(1:quantidade)) %>%
    ggplot(aes(x = reorder(nome_munic,-casos_pc), y = casos_pc)) + geom_col(fill = "azure3") + ggtitle("Cidades com os maiores números de casos por 100 mil habitantes") +
    xlab("Cidade") + ylab("Número de casos por 100 mil habitantes") + theme_classic() +
    geom_text(aes(
      label = format(
        round(casos_pc, 0),
        decimal.mark = ",",
        big.mark = ".",
        big.interval = 3L
      )
    ),
    vjust = 1)
  
  grid.arrange(cidade_menores_casos,
               cidade_maiores_casos)
}

#FUNÇÃO TRAZ A LISTA DAS CIDADES COM OS MENORES E MAIORES NÚMEROS DE ÓBITOS POR 100 MIL HABITANTES
raking_cidades_obitos <- function(quantidade = 5) {
  cidade_menores_obitos <-
    dados_covid_sp %>% filter(datahora == max(datahora)) %>%
    select(nome_munic, obitos_pc)  %>%
    filter(obitos_pc > 0) %>%
    arrange(obitos_pc) %>%
    slice(c(1:quantidade)) %>%
    ggplot(aes(x = reorder(nome_munic, obitos_pc), y = obitos_pc)) + geom_col(fill = "azure3") + ggtitle("Cidades com os menores números de óbitos por 100 mil habitantes") +
    xlab("Cidade") + ylab("Número de óbitos") + theme_classic() +
    geom_text(aes(label = round(obitos_pc, 0)), vjust = 1)
  
  cidade_maiores_obitos <-
    dados_covid_sp %>% filter(datahora == max(datahora)) %>%
    select(nome_munic, obitos_pc) %>%
    arrange(desc(obitos_pc)) %>%
    slice(c(1:quantidade)) %>%
    ggplot(aes(x = reorder(nome_munic,-obitos_pc), y = obitos_pc)) + geom_col(fill = "azure3") + ggtitle("Cidades com os maiores números de óbitos por 100 mil habitantes") +
    xlab("Cidade") + ylab("Número de óbitos por 100 mil habitantes") + theme_classic() +
    geom_text(aes(label = round(obitos_pc, 0)), vjust = 1)
  
  
  grid.arrange(cidade_menores_obitos,
               cidade_maiores_obitos)
}
