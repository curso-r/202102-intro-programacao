#Instalando os pacotes necessários.
#Caso ja tenho os pacotes instalados, pular para o script "001_abrir_tratar_base.R"

install.packages("readr")
install.packages("dplyr")
install.packages("stringr")
install.packages("lubridate")
install.packages("ggplot2")
install.packages("gridExtra")
