


library(magrittr)



#------------------------------------ BRASILEIRÃO SÉRIE A ------------------------------------------


#------------------------------------ LISTA DE PARÂMETROS ------------------------------------------

# 2020
# 13-editorial  : Finalizações
# 10-editorial  : Finalizações Certas
# 11-editorial  : Finalizações Erradas
# 37            : Finalizações na Trave
# 38            : Finalizações para Fora
# 12            : Pênaltis Desperdiçados



# Atletas - Finalizações (total) -------------------------------------------------------------------
url_base <- 'https://api.gcn.globoesporte.globo.com/api/estatisticas/2/tipo-scout/'



end_point <- '13-editorial/atletas?page='



lista_urls <- list()



for (i in 1:33) {
  
  lista_urls[i] <- paste0(url_base, end_point, i)
  
}



import_dados <- function(dados) {
  
  httr::GET(dados) %>%
    
    httr::content(simplifyDataFrame =  TRUE) %>% 
    
    purrr::pluck('scouts') %>% 
    
    tibble::as_tibble() %>% 
    
    dplyr::mutate(finaliz_total = jogos*media) %>% 
    
    dplyr::rename('finaliz_media' = media)
  
}



atleta_finaliz_total <- purrr::map_dfr(lista_urls, import_dados) 



# Atletas - Finalizações (Certas) ------------------------------------------------------------------
url_base <- 'https://api.gcn.globoesporte.globo.com/api/estatisticas/2/tipo-scout/'



end_point <- '10-editorial/atletas?page='



lista_urls <- list()



for (i in 1:23) {
  
  lista_urls[i] <- paste0(url_base, end_point, i)
  
}



import_dados <- function(dados) {
  
  httr::GET(dados) %>%
    
    httr::content(simplifyDataFrame =  TRUE) %>% 
    
    purrr::pluck('scouts') %>% 
    
    tibble::as_tibble() %>% 
    
    dplyr::mutate(finaliz_certa = jogos*media) %>% 
    
    dplyr::rename('finaliz_certa_media' = media)
  
}



atleta_finaliz_certas <- purrr::map_dfr(lista_urls, import_dados)



# Atletas - Finalizações (Erradas) -----------------------------------------------------------------
url_base <- 'https://api.gcn.globoesporte.globo.com/api/estatisticas/2/tipo-scout/'



end_point <- '11-editorial/atletas?page='



lista_urls <- list()



for (i in 1:30) {
  
  lista_urls[i] <- paste0(url_base, end_point, i)
  
}



import_dados <- function(dados) {
  
  httr::GET(dados) %>%
    
    httr::content(simplifyDataFrame =  TRUE) %>% 
    
    purrr::pluck('scouts') %>% 
    
    tibble::as_tibble() %>% 
    
    dplyr::mutate(finaliz_errada = jogos*media) %>% 
    
    dplyr::rename('finaliz_errada_media' = media)
  
}



atleta_finaliz_erradas <- purrr::map_dfr(lista_urls, import_dados)



# Atletas - Finalizações (Trave) -------------------------------------------------------------------
url_base <- 'https://api.gcn.globoesporte.globo.com/api/estatisticas/2/tipo-scout/'



end_point <- '37/atletas?page='



lista_urls <- list()



for (i in 1:5) {
  
  lista_urls[i] <- paste0(url_base, end_point, i)
  
}



import_dados <- function(dados) {
  
  httr::GET(dados) %>%
    
    httr::content(simplifyDataFrame =  TRUE) %>% 
    
    purrr::pluck('scouts') %>% 
    
    tibble::as_tibble() %>% 
    
    dplyr::mutate(finaliz_trave = jogos*media) %>% 
    
    dplyr::rename('finaliz_trave_media' = media)
  
}



atleta_finaliz_trave <- purrr::map_dfr(lista_urls, import_dados)



# Atletas - Finalizações (Fora) -------------------------------------------------------------------
url_base <- 'https://api.gcn.globoesporte.globo.com/api/estatisticas/2/tipo-scout/'



end_point <- '38/atletas?page='



lista_urls <- list()



for (i in 1:26) {
  
  lista_urls[i] <- paste0(url_base, end_point, i)
  
}



import_dados <- function(dados) {
  
  httr::GET(dados) %>%
    
    httr::content(simplifyDataFrame =  TRUE) %>% 
    
    purrr::pluck('scouts') %>% 
    
    tibble::as_tibble() %>% 
    
    dplyr::mutate(finaliz_fora = jogos*media) %>% 
    
    dplyr::rename('finaliz_fora_media' = media)
  
}



atleta_finaliz_fora <- purrr::map_dfr(lista_urls, import_dados)



# Atletas - Pênaltis Perdidos ----------------------------------------------------------------------
url_base <- 'https://api.gcn.globoesporte.globo.com/api/estatisticas/2/tipo-scout/'



end_point <- '12-editorial/atletas?page=1'



url_penaltis_perdidos <- paste0(url_base, end_point)



atleta_penaltis_perdidos <- httr::GET(url_penaltis_perdidos) %>%
  
  httr::content(simplifyDataFrame =  TRUE) %>% 
  
  purrr::pluck('scouts') %>% 
  
  tibble::as_tibble() %>%
  
  dplyr::mutate(penaltis_perdidos = jogos*media) %>% 
  
  dplyr::rename('penaltis_peridos_media' = media)



# Controle de Objetos e Finalização ----------------------------------------------------------------
finalizacoes_atletas <- dplyr::bind_rows(atleta_finaliz_total,
                                         
                                         atleta_finaliz_certas,
                                         
                                         atleta_finaliz_trave,
                                         
                                         atleta_finaliz_erradas,
                                         
                                         atleta_finaliz_fora,
                                         
                                         atleta_penaltis_perdidos)    



finalizacoes1.1 <- finalizacoes_atletas$atleta$nome_popular

finalizacoes1.2 <- finalizacoes_atletas$atleta$posicao

finalizacoes1.3 <- finalizacoes_atletas$atleta$atleta_id

finalizacoes2 <- finalizacoes_atletas$equipe

colnames(finalizacoes2) <- c('equipe_escudo',
                             
                             'equipe_id',
                             
                             'equipe_nome_popular',
                             
                             'equipe sigla')

finalizacoes3 <- as.data.frame(finalizacoes_atletas$jogos)

finalizacoes4 <- as.data.frame(finalizacoes_atletas$finaliz_media)

finalizacoes5 <- as.data.frame(finalizacoes_atletas$finaliz_total)

finalizacoes6 <- as.data.frame(finalizacoes_atletas$finaliz_certa_media)

finalizacoes7 <- as.data.frame(finalizacoes_atletas$finaliz_certa)

finalizacoes8 <- as.data.frame(finalizacoes_atletas$finaliz_errada_media)

finalizacoes9 <- as.data.frame(finalizacoes_atletas$finaliz_errada)

finalizacoes10 <- as.data.frame(finalizacoes_atletas$finaliz_fora_media)

finalizacoes11 <- as.data.frame(finalizacoes_atletas$finaliz_fora)

finalizacoes12 <- as.data.frame(finalizacoes_atletas$finaliz_trave_media)

finalizacoes13 <- as.data.frame(finalizacoes_atletas$finaliz_trave)

finalizacoes14 <- as.data.frame(finalizacoes_atletas$penaltis_peridos_media)

finalizacoes15 <- as.data.frame(finalizacoes_atletas$penaltis_perdidos)




finalizacoes_final <- cbind(finalizacoes1.1,
                              
                            finalizacoes1.2,
                              
                            finalizacoes1.3,
                              
                            finalizacoes2,
                              
                            finalizacoes3,
                              
                            finalizacoes4,
                              
                            finalizacoes5,
                              
                            finalizacoes6,
                              
                            finalizacoes7,
                            
                            finalizacoes8,
                            
                            finalizacoes9,
                            
                            finalizacoes10,
                            
                            finalizacoes11,
                            
                            finalizacoes12,
                            
                            finalizacoes13,
                            
                            finalizacoes14,
                            
                            finalizacoes15) %>% 
  
  tibble::as_tibble() %>% 
  
  janitor::clean_names()



rm(list = ls()[ls() != 'finalizacoes_final'])



# Exportação dos Dados -----------------------------------------------------------------------------
write.csv2(finalizacoes_final, 'dados/finalizacoes.csv')


writexl::write_xlsx(finalizacoes_final, 'dados/finalizacoes.xlsx')


beepr::beep(8)



