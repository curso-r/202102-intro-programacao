


library(magrittr)



#------------------------------------ BRASILEIRÃO SÉRIE A ------------------------------------------


#------------------------------------ LISTA DE PARÂMETROS ------------------------------------------

# 2020
# 31            : Faltas Recebidas
# 30            : Faltas Cometidas
# 42            : Impedimentos



# Atletas - Faltas Recebidas -----------------------------------------------------------------------
url_base <- 'https://api.gcn.globoesporte.globo.com/api/estatisticas/2/tipo-scout/'



end_point <- '31/atletas?page='



lista_urls <- list()



for (i in 1:36) {
  
  lista_urls[i] <- paste0(url_base, end_point, i)
  
}



import_dados <- function(dados) {
  
  httr::GET(dados) %>%
    
    httr::content(simplifyDataFrame =  TRUE) %>% 
    
    purrr::pluck('scouts') %>% 
    
    tibble::as_tibble() %>% 
    
    dplyr::mutate(falta_recebida = jogos*media) %>% 
    
    dplyr::rename('falta_recebida_media' = media)
  
}



atleta_falta_recebida <- purrr::map_dfr(lista_urls, import_dados) 



# Atletas - Faltas Cometidas -----------------------------------------------------------------------
url_base <- 'https://api.gcn.globoesporte.globo.com/api/estatisticas/2/tipo-scout/'



end_point <- '30/atletas?page='



lista_urls <- list()



for (i in 1:30) {
  
  lista_urls[i] <- paste0(url_base, end_point, i)
  
}



import_dados <- function(dados) {
  
  httr::GET(dados) %>%
    
    httr::content(simplifyDataFrame =  TRUE) %>% 
    
    purrr::pluck('scouts') %>% 
    
    tibble::as_tibble() %>% 
    
    dplyr::mutate(falta_cometida = jogos*media) %>% 
    
    dplyr::rename('falta_cometida_media' = media)
  
}



atleta_falta_cometida <- purrr::map_dfr(lista_urls, import_dados)



# Atletas - Impedimentos ---------------------------------------------------------------------------
url_base <- 'https://api.gcn.globoesporte.globo.com/api/estatisticas/2/tipo-scout/'



end_point <- '42/atletas?page='



lista_urls <- list()



for (i in 1:11) {
  
  lista_urls[i] <- paste0(url_base, end_point, i)
  
}



import_dados <- function(dados) {
  
  httr::GET(dados) %>%
    
    httr::content(simplifyDataFrame =  TRUE) %>% 
    
    purrr::pluck('scouts') %>% 
    
    tibble::as_tibble() %>% 
    
    dplyr::mutate(impedimentos = jogos*media) %>% 
    
    dplyr::rename('impedimentos_media' = media)
  
}



atleta_impedimentos <- purrr::map_dfr(lista_urls, import_dados)



# Controle de Objetos e Finalização ----------------------------------------------------------------
faltas_atletas <- dplyr::bind_rows(atleta_falta_recebida,
                                         
                                   atleta_falta_cometida,
                                         
                                   atleta_impedimentos)


faltas_atletas_1.1 <- faltas_atletas$atleta$nome_popular

faltas_atletas_1.2 <- faltas_atletas$atleta$posicao

faltas_atletas_1.3 <- faltas_atletas$atleta$atleta_id

faltas_atletas_2 <- faltas_atletas$equipe

colnames(faltas_atletas_2) <- c('equipe_escudo',
                                
                                'equipe_id',
                                
                                'equipe_nome_popular',
                                
                                'equipe sigla')

faltas_atletas_3 <- as.data.frame(faltas_atletas$jogos)

faltas_atletas_4 <- as.data.frame(faltas_atletas$falta_recebida_media)

faltas_atletas_5 <- as.data.frame(faltas_atletas$falta_recebida)

faltas_atletas_6 <- as.data.frame(faltas_atletas$falta_cometida_media)

faltas_atletas_7 <- as.data.frame(faltas_atletas$falta_cometida)



faltas_atletas_final <- cbind(faltas_atletas_1.1,
                              
                              faltas_atletas_1.2,
                              
                              faltas_atletas_1.3,
                              
                              faltas_atletas_2,
                              
                              faltas_atletas_3,
                              
                              faltas_atletas_4,
                              
                              faltas_atletas_5,
                              
                              faltas_atletas_6,
                              
                              faltas_atletas_7) %>% 
  
  tibble::as_tibble() %>% 
  
  janitor::clean_names()


rm(list = ls()[ls() != 'faltas_atletas_final'])



# Exportação dos Dados -----------------------------------------------------------------------------
write.csv2(faltas_atletas_final, 'dados/faltas_atletas.csv')


writexl::write_xlsx(faltas_atletas_final, 'dados/faltas_atletas.xlsx')


beepr::beep(8)


