


library(magrittr)



#------------------------------------ BRASILEIRÃO SÉRIE A ------------------------------------------


#------------------------------------ LISTA DE PARÂMETROS ------------------------------------------

# 2020
# 46   : Cartões Vermelhos



# Atletas - Cartões Vermelhos ----------------------------------------------------------------------
url_base <- 'https://api.gcn.globoesporte.globo.com/api/estatisticas/2/tipo-scout/'



end_point <- '26/atletas?page='



lista_urls <- list()



for (i in 1:3) {
  
  lista_urls[i] <- paste0(url_base, end_point, i)
  
}



import_dados <- function(dados) {
  
  httr::GET(dados) %>%
    
    httr::content(simplifyDataFrame =  TRUE) %>% 
    
    purrr::pluck('scouts') %>% 
    
    tibble::as_tibble() %>% 
    
    dplyr::mutate(cartao_vermelho = jogos*media) %>% 
    
    dplyr::rename('cartao_vermelho_media' = media)
  
}



atleta_cartao_vermelho <- purrr::map_dfr(lista_urls, import_dados) 



# Controle de Objetos e Finalização ----------------------------------------------------------------
cartao_vermelho1 <- atleta_cartao_vermelho$atleta$nome_popular

cartao_vermelho2 <- atleta_cartao_vermelho$atleta$posicao

cartao_vermelho3 <- atleta_cartao_vermelho$atleta$atleta_id

cartao_vermelho4 <- atleta_cartao_vermelho$equipe

colnames(cartao_vermelho4) <- c('equipe_escudo',
                                
                                'equipe_id',
                                
                                'equipe_nome_popular',
                                
                                'equipe sigla')

cartao_vermelho5 <- as.data.frame(atleta_cartao_vermelho$jogos)
  
cartao_vermelho6 <- as.data.frame(atleta_cartao_vermelho$cartao_vermelho_media)
  
cartao_vermelho7 <- as.data.frame(atleta_cartao_vermelho$cartao_vermelho)

cartao_vermelho_final <- cbind(cartao_vermelho1,
                               
                               cartao_vermelho2,
                               
                               cartao_vermelho3,
                               
                               cartao_vermelho4,
                               
                               cartao_vermelho5,
                               
                               cartao_vermelho6,
                               
                               cartao_vermelho7) %>% 
  
  tibble::as_tibble() %>% 
  
  janitor::clean_names()



rm(list = ls()[ls() != 'cartao_vermelho_final'])



# Exportação dos Dados -----------------------------------------------------------------------------
write.csv2(cartao_vermelho_final, 'dados/cartao_vermelho.csv')


writexl::write_xlsx(cartao_vermelho_final, 'dados/cartao_vermelho.xlsx')


beepr::beep(8)