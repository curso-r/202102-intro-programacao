


library(magrittr)



#------------------------------------ BRASILEIRÃO SÉRIE A ------------------------------------------


#------------------------------------ LISTA DE PARÂMETROS ------------------------------------------

# 2020
# 9-editorial   : Assistências
# 43            : Passes Errados
# 46            : Roubadas de Bola



# Atletas - Assistências ---------------------------------------------------------------------------
url_base <- 'https://api.gcn.globoesporte.globo.com/api/estatisticas/2/tipo-scout/'



end_point <- '9-editorial/atletas?page='



lista_urls <- list()



for (i in 1:8) {
  
  lista_urls[i] <- paste0(url_base, end_point, i)
  
}



import_dados <- function(dados) {
  
  httr::GET(dados) %>%
    
    httr::content(simplifyDataFrame =  TRUE) %>% 
    
    purrr::pluck('scouts') %>% 
    
    tibble::as_tibble() %>% 
    
    dplyr::mutate(assistencias = jogos*media) %>% 
    
    dplyr::rename('assistencias_media' = media)
  
}



atleta_assistencias <- purrr::map_dfr(lista_urls, import_dados)



# Atletas - Passes Errados -------------------------------------------------------------------------
url_base <- 'https://api.gcn.globoesporte.globo.com/api/estatisticas/2/tipo-scout/'



end_point <- '43/atletas?page='



lista_urls <- list()



for (i in 1:42) {
  
  lista_urls[i] <- paste0(url_base, end_point, i)
  
}



import_dados <- function(dados) {
  
  httr::GET(dados) %>%
    
    httr::content(simplifyDataFrame =  TRUE) %>% 
    
    purrr::pluck('scouts') %>% 
    
    tibble::as_tibble() %>% 
    
    dplyr::mutate(passes_errados = jogos*media) %>% 
    
    dplyr::rename('passes_errados_media' = media)
  
}



atleta_passes_errados <- purrr::map_dfr(lista_urls, import_dados)



# Atletas - Impedimentos ---------------------------------------------------------------------------
url_base <- 'https://api.gcn.globoesporte.globo.com/api/estatisticas/2/tipo-scout/'



end_point <- '46/atletas?page='



lista_urls <- list()



for (i in 1:36) {
  
  lista_urls[i] <- paste0(url_base, end_point, i)
  
}



import_dados <- function(dados) {
  
  httr::GET(dados) %>%
    
    httr::content(simplifyDataFrame =  TRUE) %>% 
    
    purrr::pluck('scouts') %>% 
    
    tibble::as_tibble() %>% 
    
    dplyr::mutate(roubada_bola = jogos*media) %>% 
    
    dplyr::rename('roubada_bola_media' = media)
  
}



atleta_roubada_bola <- purrr::map_dfr(lista_urls, import_dados)



# Controle de Objetos e Finalização ----------------------------------------------------------------
passes_atletas <- dplyr::bind_rows(atleta_assistencias,
                                   
                                   atleta_passes_errados,
                                   
                                   atleta_roubada_bola) 



passes_atletas_1.1 <- passes_atletas$atleta$nome_popular

passes_atletas_1.2 <- passes_atletas$atleta$posicao
  
passes_atletas_1.3 <- passes_atletas$atleta$atleta_id

passes_atletas_2 <- passes_atletas$equipe

colnames(passes_atletas_2) <- c('equipe_escudo',
                                
                                'equipe_id',
                                
                                'equipe_nome_popular',
                                
                                'equipe sigla')

passes_atletas_3 <- as.data.frame(passes_atletas$jogos)

passes_atletas_4 <- as.data.frame(passes_atletas$assistencias_media)

passes_atletas_5 <- as.data.frame(passes_atletas$assistencias)

passes_atletas_6 <- as.data.frame(passes_atletas$passes_errados_media)

passes_atletas_7 <- as.data.frame(passes_atletas$passes_errados)

passes_atletas_8 <- as.data.frame(passes_atletas$roubada_bola_media)

passes_atletas_9 <- as.data.frame(passes_atletas$roubada_bola)


passes_atletas_final <- cbind(passes_atletas_1.1,
                              
                              passes_atletas_1.2,
                              
                              passes_atletas_1.3,
                              
                              passes_atletas_2,
                              
                              passes_atletas_3,
                              
                              passes_atletas_4,
                              
                              passes_atletas_5,
                              
                              passes_atletas_6,
                              
                              passes_atletas_7,
                              
                              passes_atletas_8,
                              
                              passes_atletas_9) %>% 
  
                        tibble::as_tibble() %>% 
  
                        janitor::clean_names()



rm(list = ls()[ls() != 'passes_atletas_final'])



# Exportação dos Dados -----------------------------------------------------------------------------
write.csv2(passes_atletas_final, 'dados/passes_atletas.csv')


writexl::write_xlsx(passes_atletas_final, 'dados/passes_atletas.xlsx')


beepr::beep(8)
