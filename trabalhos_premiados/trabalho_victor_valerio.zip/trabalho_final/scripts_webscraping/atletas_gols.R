


library(magrittr)



#------------------------------------ BRASILEIRÃO SÉRIE A ------------------------------------------


#------------------------------------ LISTA DE PARÂMETROS ------------------------------------------

# 2020
# 39          : Gols Marcados
# 41          : Gols Sofridos
# 40          : Gols Contra
# 8-editorial : Gols de Cabeça
# 32          : Gols de Falta
# 33          : Gols de Pênalti
# 48          : Gols Dentro da Área
# 36          : Gols Fora da Área



# Atletas - Gol Marcado ----------------------------------------------------------------------------
url_base <- 'https://api.gcn.globoesporte.globo.com/api/estatisticas/2/tipo-scout/'



end_point <- '39/atletas?page='



lista_urls <- list()



for (i in 1:11) {
  
  lista_urls[i] <- paste0(url_base, end_point, i)
  
}



import_dados <- function(dados) {
  
  httr::GET(dados) %>%
    
    httr::content(simplifyDataFrame =  TRUE) %>% 
    
    purrr::pluck('scouts') %>% 
    
    tibble::as_tibble() %>% 
    
    dplyr::mutate(gols_marcados_total = jogos*media) %>% 
    
    dplyr::rename('gols_marcados_media' = media)
  
}



atleta_gol_marcado <- purrr::map_dfr(lista_urls, import_dados) 



# Atletas - Gol Sofrido ----------------------------------------------------------------------------
url_base <- 'https://api.gcn.globoesporte.globo.com/api/estatisticas/2/tipo-scout/'



end_point <- '41/atletas?page='



lista_urls <- list()



for (i in 1:3) {
  
  lista_urls[i] <- paste0(url_base, end_point, i)
  
}



import_dados <- function(dados) {
  
  httr::GET(dados) %>%
    
    httr::content(simplifyDataFrame =  TRUE) %>% 
    
    purrr::pluck('scouts') %>% 
    
    tibble::as_tibble() %>% 
    
    dplyr::mutate(gols_sofridos_total = jogos*media) %>% 
    
    dplyr::rename('gols_sofridos_media' = media)
  
}



atleta_gol_sofrido <- purrr::map_dfr(lista_urls, import_dados) 



# Atletas - Gol Contra -----------------------------------------------------------------------------
url_base <- 'https://api.gcn.globoesporte.globo.com/api/estatisticas/2/tipo-scout/'



end_point <- '40/atletas?page=1'



url_gol_contra <- paste0(url_base, end_point)



atleta_gol_contra <- httr::GET(url_gol_contra) %>%
    
    httr::content(simplifyDataFrame =  TRUE) %>% 
    
    purrr::pluck('scouts') %>% 
    
    tibble::as_tibble() %>%
  
    dplyr::mutate(gols_contra_total = jogos*media) %>% 
  
    dplyr::rename('gols_contra_media' = media)



# Atletas - Gol de Cabeça --------------------------------------------------------------------------
url_base <- 'https://api.gcn.globoesporte.globo.com/api/estatisticas/2/tipo-scout/'



end_point <- '8-editorial/atletas?page='



lista_urls <- list()



for (i in 1:3) {
  
  lista_urls[i] <- paste0(url_base, end_point, i)
  
}



import_dados <- function(dados) {
  
  httr::GET(dados) %>%
    
    httr::content(simplifyDataFrame =  TRUE) %>% 
    
    purrr::pluck('scouts') %>% 
    
    tibble::as_tibble() %>% 
    
    dplyr::mutate(gols_cabeca_total = jogos*media) %>% 
    
    dplyr::rename('gols_cabeca_media' = media)
  
}



atleta_gol_cabeca <- purrr::map_dfr(lista_urls, import_dados) 



# Atletas - Gol de Falta ---------------------------------------------------------------------------
url_base <- 'https://api.gcn.globoesporte.globo.com/api/estatisticas/2/tipo-scout/'



end_point <- '32/atletas?page=1'



url_gol_falta <- paste0(url_base, end_point)



atleta_gol_falta <- httr::GET(url_gol_falta) %>%
  
  httr::content(simplifyDataFrame =  TRUE) %>% 
  
  purrr::pluck('scouts') %>% 
  
  tibble::as_tibble() %>% 
  
  dplyr::mutate(gols_defalta_total = jogos*media) %>% 
  
  dplyr::rename('gols_defalta_media' = media)



# Atletas - Gol de Pênalti -------------------------------------------------------------------------
url_base <- 'https://api.gcn.globoesporte.globo.com/api/estatisticas/2/tipo-scout/'



end_point <- '33/atletas?page='



lista_urls <- list()



for (i in 1:2) {
  
  lista_urls[i] <- paste0(url_base, end_point, i)
  
}



import_dados <- function(dados) {
  
  httr::GET(dados) %>%
    
    httr::content(simplifyDataFrame =  TRUE) %>% 
    
    purrr::pluck('scouts') %>% 
    
    tibble::as_tibble() %>% 
    
    dplyr::mutate(gols_penalti_total = jogos*media) %>% 
    
    dplyr::rename('gols_penalti_media' = media)
  
}



atleta_gol_penalti <- purrr::map_dfr(lista_urls, import_dados) 



# Atletas - Gol Dentro da Área ---------------------------------------------------------------------
url_base <- 'https://api.gcn.globoesporte.globo.com/api/estatisticas/2/tipo-scout/'



end_point <- '48/atletas?page='



lista_urls <- list()



for (i in 1:7) {
  
  lista_urls[i] <- paste0(url_base, end_point, i)
  
}



import_dados <- function(dados) {
  
  httr::GET(dados) %>%
    
    httr::content(simplifyDataFrame =  TRUE) %>% 
    
    purrr::pluck('scouts') %>% 
    
    tibble::as_tibble() %>% 
    
    dplyr::mutate(gols_dentroarea_total = jogos*media) %>% 
    
    dplyr::rename('gols_dentroarea_media' = media)
  
}



atleta_gol_dentro_area <- purrr::map_dfr(lista_urls, import_dados) 



# Atletas - Gol Fora da Área -----------------------------------------------------------------------
url_base <- 'https://api.gcn.globoesporte.globo.com/api/estatisticas/2/tipo-scout/'



end_point <- '36/atletas?page='



lista_urls <- list()



for (i in 1:2) {
  
  lista_urls[i] <- paste0(url_base, end_point, i)
  
}



import_dados <- function(dados) {
  
  httr::GET(dados) %>%
    
    httr::content(simplifyDataFrame =  TRUE) %>% 
    
    purrr::pluck('scouts') %>% 
    
    tibble::as_tibble() %>% 
    
    dplyr::mutate(gols_foraarea_total = jogos*media) %>% 
    
    dplyr::rename('gols_foraarea_media' = media)
  
}



atleta_gol_fora_area <- purrr::map_dfr(lista_urls, import_dados) 



# Controle de Objetos e Finalização ----------------------------------------------------------------
gols_atletas <- dplyr::bind_rows(atleta_gol_marcado, 
                                 
                                 atleta_gol_cabeca,
                                 
                                 atleta_gol_falta,
                                 
                                 atleta_gol_penalti,
                                 
                                 atleta_gol_dentro_area,
                                 
                                 atleta_gol_fora_area,
                                 
                                 atleta_gol_contra,
                                 
                                 atleta_gol_sofrido)



gols1.1 <- gols_atletas$atleta$nome_popular

gols1.2 <- gols_atletas$atleta$posicao

gols1.3 <- gols_atletas$atleta$atleta_id

gols2 <- gols_atletas$equipe

colnames(gols2) <- c('equipe_escudo',
                     
                     'equipe_id',
                     
                     'equipe_nome_popular',
                     
                     'equipe sigla')

gols3 <- as.data.frame(gols_atletas$jogos)

gols4 <- as.data.frame(gols_atletas$gols_marcados_media)

gols5 <- as.data.frame(gols_atletas$gols_marcados_total)

gols6 <- as.data.frame(gols_atletas$gols_cabeca_media)

gols7 <- as.data.frame(gols_atletas$gols_cabeca_total)

gols8 <- as.data.frame(gols_atletas$gols_defalta_media)

gols9 <- as.data.frame(gols_atletas$gols_defalta_total)

gols10 <- as.data.frame(gols_atletas$gols_foraarea_media)

gols11 <- as.data.frame(gols_atletas$gols_foraarea_total)

gols12 <- as.data.frame(gols_atletas$gols_penalti_media)

gols13 <- as.data.frame(gols_atletas$gols_penalti_total)

gols14 <- as.data.frame(gols_atletas$gols_dentroarea_media)

gols15 <- as.data.frame(gols_atletas$gols_dentroarea_total)

gols16 <- as.data.frame(gols_atletas$gols_contra_media)

gols17 <- as.data.frame(gols_atletas$gols_contra_total)

gols18 <- as.data.frame(gols_atletas$gols_sofridos_media)

gols19 <- as.data.frame(gols_atletas$gols_sofridos_total)



gols_final <- passes_atletas_final <- cbind(gols1.1,
                                            
                                            gols1.2,
                                            
                                            gols1.3,
                                            
                                            gols2,
                                            
                                            gols3,
                                            
                                            gols4,
                                            
                                            gols5,
                                            
                                            gols6,
                                            
                                            gols7,
                                            
                                            gols8,
                                            
                                            gols9,
                                            
                                            gols10,
                                            
                                            gols11,
                                            
                                            gols12,
                                            
                                            gols13,
                                            
                                            gols14,
                                            
                                            gols15,
                                            
                                            gols16,
                                            
                                            gols17,
                                            
                                            gols18,
                                            
                                            gols19) %>% 
  
  tibble::as_tibble() %>% 
  
  janitor::clean_names()



rm(list = ls()[ls() != 'gols_final'])



# Exportação dos Dados -----------------------------------------------------------------------------
write.csv2(gols_final, 'dados/gols.csv')


writexl::write_xlsx(gols_final, 'dados/gols.xlsx')


beepr::beep(8)


